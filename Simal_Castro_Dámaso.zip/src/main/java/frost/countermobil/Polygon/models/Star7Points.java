package frost.countermobil.Polygon.models;

public class Star7Points extends Figure{



}
