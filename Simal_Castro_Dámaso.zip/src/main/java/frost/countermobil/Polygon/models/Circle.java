package frost.countermobil.Polygon.models;

public class Circle extends Figure{


}
