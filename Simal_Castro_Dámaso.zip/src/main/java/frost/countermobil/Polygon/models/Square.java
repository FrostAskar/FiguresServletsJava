package frost.countermobil.Polygon.models;

public class Square extends Figure{



}
