const canvas = document.getElementById('polygonCanvas');
const ctx = canvas.getContext("2d");
function draw(choice, x, y, size, color){
    
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    ctx.strokeStyle = color;
    ctx.fillStyle = color;
    ctx.beginPath();
    switch (choice) {
        case "Circle":    
            ctx.arc(x, y, size, 0, 2 * Math.PI);
            break;
        case "Square":
            ctx.rect(x - size, y - size, size * 2, size * 2);
            break;
        case "Triangle":
            ctx.moveTo(x, y - (size));
            ctx.lineTo(x - (size), y + (size));
            ctx.lineTo(x + (size), y + (size));
            ctx.lineTo(x, y - (size));
            break;
        case "Pentagon":
            step  = 2 * Math.PI / 5
            shift = (Math.PI / 180.0) * -18
            for (let i = 0; i <= 5; i++) {
                let curStep = i * step + shift;
                ctx.lineTo (x + size * Math.cos(curStep), y + size * Math.sin(curStep));
            }
            break;
        case "7-pointed-star":
            ctx.moveTo(x, y + size);
            for (let i=0; i < 2*7+1; i++) {
                let r = (i%2 == 0)? size : size/2;
                let a = Math.PI * i/7;
                ctx.lineTo(x + r*Math.sin(a), y + r*Math.cos(a));
            };
            break;
    }
    ctx.stroke();
    ctx.fill();
}