package frost.countermobil.Polygon.models;

public class Triangle extends Figure{


}
