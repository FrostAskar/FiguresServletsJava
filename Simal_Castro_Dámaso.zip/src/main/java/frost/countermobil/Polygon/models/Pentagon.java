package frost.countermobil.Polygon.models;

public class Pentagon extends Figure{



}
